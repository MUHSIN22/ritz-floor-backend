module.exports = {
	HOST: "ds.techjainsupport.co.in",
	USER: "techjain_fnm",
	PASSWORD: "Techjain@123",
	DB: "techjain_ritzf",
	dialect: "mysql",
	pool: {
		max: 5,
		min: 0,
		accquire: 30000,
		idle: 10000,
	},
};


// module.exports = {
// 	HOST: "localhost",
// 	USER: "root",
// 	PASSWORD: "Muhsin@123",
// 	DB: "ritzfoor-admin-dashboard",
// 	dialect: "mysql",
// 	pool: {
// 		max: 5,
// 		min: 0,
// 		accquire: 30000,
// 		idle: 10000,
// 	},
// };

// ORACLE_URL=ds.techjainsupport.co.in
// ORACLE_USER=techjain_fnm
// ORACLE_PASSWORD=Techjain@123
// module.exports = {
// 	HOST: "ds.techjainsupport.co.in",
// 	USER: "techjain_fnm",
// 	PASSWORD: "Techjain@123",
// 	DB: "techjain_ritzf",
// 	dialect: "mysql",
// 	pool: {
// 		max: 5,
// 		min: 0,
// 		accquire: 30000,
// 		idle: 10000,
// 	},
// };